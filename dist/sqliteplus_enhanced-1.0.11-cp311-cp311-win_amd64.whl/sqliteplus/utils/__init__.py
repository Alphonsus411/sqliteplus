"""Utility helpers for the sqliteplus package."""
